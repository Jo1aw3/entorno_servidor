<?php

require_once 'ConectarBase.php';

class EditorialesModel
{
    
}