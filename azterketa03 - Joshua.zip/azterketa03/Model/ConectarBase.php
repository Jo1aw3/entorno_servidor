<?php

class ConectarBase {
    public $host = 'localhost';
    public $userbd = 'root';
    public $passbd = '';
    public $namebd = 'editorial';
}
